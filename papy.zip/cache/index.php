<!DOCTYPE html>
<html>
<head>

	<title>Access Forbidden!</title>

	<style type="text/css">

		body {
			font-family: Arial;
			font-size: 12px;
			color: #FFF;	
		}

		#ErrorOkvir {
			margin-top: 80px;
		}

		.errorSajt {
			text-align: center;
		}

		.errorSajt a {
			color: #009cff; 
			text-decoration: none; 
			font-weight: bold;
			font-size: 15px;
		}
.copyright {
		color:#fff;
		font-family: Geneva, Arial, Helvetica, sans-serif;
		font-size: 15px;
		margin: 15px 0 0;
		padding-top: 50px;
		text-align: center;
		}
		
                .poweredbox {
                    font-family: Geneva, Arial, Helvetica, sans-serif;
                    color:#000000;
                    padding-left: 15px;
                }

	</style>

</head>

<body style="background-color: #000000;">

	<div id="ErrorOkvir">
		
		<h1 style="text-align: center; font-weight: bold;">Error - Access Forbidden!</h1>

		<hr />

		<h3 style="text-align: center; font-weight: bold;">You are not authorised to view this page or directory....!</h3>

	</div>

</body>
</html>

<div class="copyright">
<p><strong>Powered by <a href="https://hq-hosting.me">hq-hosting.me</a></strong>&nbsp;.</p>
</div>
</body>
</html>